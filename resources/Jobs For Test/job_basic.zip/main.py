from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import time
import json

print("🚀 Starting scikit-learn Random Forest Training...")
print(f"Python ML Training Pipeline v1.0\n")

# Generate synthetic dataset
print("📊 Generating synthetic dataset...")
X, y = make_classification(
    n_samples=5000,
    n_features=20,
    n_informative=15,
    n_redundant=5,
    n_classes=2,
    random_state=42
)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"   ✓ Dataset created:")
print(f"     - Total samples: {len(X)}")
print(f"     - Features: {X.shape[1]}")
print(f"     - Training samples: {len(X_train)}")
print(f"     - Test samples: {len(X_test)}")
print(f"     - Class distribution: {sum(y)} positive, {len(y)-sum(y)} negative\n")

# Train Random Forest model
print("🏋️  Training Random Forest Classifier...")
print("-" * 60)

model = RandomForestClassifier(
    n_estimators=100,
    max_depth=10,
    min_samples_split=5,
    random_state=42,
    verbose=1,
    n_jobs=-1
)

start_time = time.time()
model.fit(X_train, y_train)
training_time = time.time() - start_time

print("-" * 60)
print(f"✅ Training completed in {training_time:.2f} seconds\n")

# Make predictions
print("🔮 Making predictions...")
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

# Calculate metrics
train_acc = accuracy_score(y_train, y_train_pred)
test_acc = accuracy_score(y_test, y_test_pred)
conf_matrix = confusion_matrix(y_test, y_test_pred)

print(f"   ✓ Training Accuracy: {train_acc:.4f}")
print(f"   ✓ Test Accuracy: {test_acc:.4f}\n")

# Save model
print("💾 Saving outputs...")
model_filename = "random_forest_model.pkl"
joblib.dump(model, model_filename)
print(f"   ✓ Model saved to {model_filename}")

# Save detailed metrics report
report_filename = "training_report.txt"
with open(report_filename, "w") as f:
    f.write("=" * 70 + "\n")
    f.write("         RANDOM FOREST CLASSIFIER - TRAINING REPORT\n")
    f.write("=" * 70 + "\n\n")
    
    f.write("MODEL CONFIGURATION\n")
    f.write("-" * 70 + "\n")
    f.write(f"Algorithm:          Random Forest Classifier\n")
    f.write(f"Number of Trees:    100\n")
    f.write(f"Max Depth:          10\n")
    f.write(f"Min Samples Split:  5\n")
    f.write(f"Random State:       42\n\n")
    
    f.write("DATASET INFORMATION\n")
    f.write("-" * 70 + "\n")
    f.write(f"Total Samples:      {len(X)}\n")
    f.write(f"Features:           {X.shape[1]}\n")
    f.write(f"Training Samples:   {len(X_train)} ({len(X_train)/len(X)*100:.1f}%)\n")
    f.write(f"Test Samples:       {len(X_test)} ({len(X_test)/len(X)*100:.1f}%)\n")
    f.write(f"Positive Class:     {sum(y)} samples\n")
    f.write(f"Negative Class:     {len(y)-sum(y)} samples\n\n")
    
    f.write("TRAINING RESULTS\n")
    f.write("-" * 70 + "\n")
    f.write(f"Training Time:      {training_time:.2f} seconds\n")
    f.write(f"Training Accuracy:  {train_acc:.4f} ({train_acc*100:.2f}%)\n")
    f.write(f"Test Accuracy:      {test_acc:.4f} ({test_acc*100:.2f}%)\n\n")
    
    f.write("CONFUSION MATRIX (Test Set)\n")
    f.write("-" * 70 + "\n")
    f.write(f"                Predicted Negative    Predicted Positive\n")
    f.write(f"Actual Negative        {conf_matrix[0][0]:4d}                  {conf_matrix[0][1]:4d}\n")
    f.write(f"Actual Positive        {conf_matrix[1][0]:4d}                  {conf_matrix[1][1]:4d}\n\n")
    
    f.write("DETAILED CLASSIFICATION REPORT\n")
    f.write("-" * 70 + "\n")
    f.write(classification_report(y_test, y_test_pred, target_names=['Negative', 'Positive']))
    f.write("\n")
    
    f.write("FEATURE IMPORTANCE (Top 10)\n")
    f.write("-" * 70 + "\n")
    importances = model.feature_importances_
    indices = importances.argsort()[::-1][:10]
    for i, idx in enumerate(indices, 1):
        f.write(f"{i:2d}. Feature {idx:2d}:  {importances[idx]:.4f}\n")
    
    f.write("\n" + "=" * 70 + "\n")
    f.write("Training completed successfully!\n")
    f.write("=" * 70 + "\n")

print(f"   ✓ Report saved to {report_filename}")

# Save metrics as JSON for easy parsing
metrics_filename = "metrics.json"
metrics = {
    "training_accuracy": float(train_acc),
    "test_accuracy": float(test_acc),
    "training_time_seconds": float(training_time),
    "n_estimators": 100,
    "max_depth": 10,
    "total_samples": len(X),
    "training_samples": len(X_train),
    "test_samples": len(X_test),
    "confusion_matrix": conf_matrix.tolist()
}

with open(metrics_filename, "w") as f:
    json.dump(metrics, f, indent=2)

print(f"   ✓ Metrics saved to {metrics_filename}")

# Create a simple prediction example file
example_filename = "prediction_example.txt"
with open(example_filename, "w") as f:
    f.write("EXAMPLE PREDICTIONS\n")
    f.write("=" * 50 + "\n\n")
    f.write("Here are 5 example predictions from the test set:\n\n")
    for i in range(5):
        actual = y_test[i]
        predicted = y_test_pred[i]
        status = "✓ CORRECT" if actual == predicted else "✗ WRONG"
        f.write(f"Sample {i+1}: Actual={actual}, Predicted={predicted} {status}\n")

print(f"   ✓ Examples saved to {example_filename}")

print("\n" + "=" * 60)
print("🎉 TRAINING PIPELINE COMPLETED SUCCESSFULLY!")
print("=" * 60)
print(f"\n📦 Generated Output Files:")
print(f"   1. {model_filename} - Trained model (can be loaded with joblib)")
print(f"   2. {report_filename} - Detailed training report")
print(f"   3. {metrics_filename} - Machine-readable metrics")
print(f"   4. {example_filename} - Sample predictions")
print(f"\n✨ All outputs ready for download!\n")