"""
Iris Species Prediction
=======================
Trains a simple Decision Tree on the Iris dataset.
No cross-validation, no ensembles — a lightweight single-model job.
"""

import json
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

print("Loading dataset...")
data = load_iris()
X, y = data.data, data.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"Train size: {len(X_train)} | Test size: {len(X_test)}")

print("Fitting model...")
tree = DecisionTreeClassifier(max_depth=4, random_state=42)
tree.fit(X_train, y_train)

preds = tree.predict(X_test)
acc   = accuracy_score(y_test, preds)
print(f"Test accuracy: {acc:.4f}")

# Write directly to working dir — no subdirectory
with open("results.json", "w") as f:
    json.dump({"accuracy": float(acc), "classes": list(data.target_names)}, f, indent=2)

print("Done. Results saved to results.json")
