"""
MNIST Handwritten Digit Classifier — CNN
=========================================
Trains a Convolutional Neural Network on the MNIST dataset using PyTorch.
Architecture: 2x Conv layers → MaxPool → Dropout → 2x FC layers
Includes:
  - Training loop with Adam optimizer and CrossEntropyLoss
  - Per-epoch validation accuracy tracking
  - Confusion matrix and per-class accuracy on test set
  - Model checkpoint saved to outputs/
"""

import os
import json
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from sklearn.metrics import confusion_matrix, classification_report
import numpy as np

DEVICE  = torch.device("cuda" if torch.cuda.is_available() else "cpu")
EPOCHS  = 12
BATCH   = 128
LR      = 0.001

print(f"Device: {DEVICE}")
print(f"Epochs: {EPOCHS} | Batch size: {BATCH} | LR: {LR}")

# ── Data ──────────────────────────────────────────────────────────────────────
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.1307,), (0.3081,))
])

train_ds = datasets.MNIST(root="./data", train=True,  download=True, transform=transform)
test_ds  = datasets.MNIST(root="./data", train=False, download=True, transform=transform)

train_loader = DataLoader(train_ds, batch_size=BATCH, shuffle=True,  num_workers=2, pin_memory=True)
test_loader  = DataLoader(test_ds,  batch_size=BATCH, shuffle=False, num_workers=2, pin_memory=True)

print(f"\nTrain: {len(train_ds):,} samples | Test: {len(test_ds):,} samples")

# ── Model ─────────────────────────────────────────────────────────────────────
class MNISTNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout(0.25),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 14 * 14, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 10),
        )

    def forward(self, x):
        return self.classifier(self.features(x))

model     = MNISTNet().to(DEVICE)
optimizer = optim.Adam(model.parameters(), lr=LR)
scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=4, gamma=0.5)
criterion = nn.CrossEntropyLoss()

total_params = sum(p.numel() for p in model.parameters())
print(f"Model parameters: {total_params:,}")

# ── Training loop ─────────────────────────────────────────────────────────────
history = []

for epoch in range(1, EPOCHS + 1):
    model.train()
    running_loss, correct, total = 0.0, 0, 0

    for images, labels in train_loader:
        images, labels = images.to(DEVICE), labels.to(DEVICE)
        optimizer.zero_grad()
        outputs = model(images)
        loss    = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)
        _, predicted  = outputs.max(1)
        correct      += predicted.eq(labels).sum().item()
        total        += labels.size(0)

    train_loss = running_loss / total
    train_acc  = correct / total

    # Validation
    model.eval()
    val_loss, val_correct, val_total = 0.0, 0, 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            outputs = model(images)
            loss    = criterion(outputs, labels)
            val_loss    += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            val_correct += predicted.eq(labels).sum().item()
            val_total   += labels.size(0)

    val_loss /= val_total
    val_acc   = val_correct / val_total
    scheduler.step()

    history.append({"epoch": epoch, "train_loss": train_loss, "train_acc": train_acc,
                    "val_loss": val_loss, "val_acc": val_acc})
    print(f"Epoch {epoch:02d}/{EPOCHS} | "
          f"Train loss: {train_loss:.4f} acc: {train_acc:.4f} | "
          f"Val loss: {val_loss:.4f} acc: {val_acc:.4f}")

# ── Final evaluation ──────────────────────────────────────────────────────────
print("\nFinal evaluation on test set...")
model.eval()
all_preds, all_labels = [], []
with torch.no_grad():
    for images, labels in test_loader:
        images = images.to(DEVICE)
        outputs = model(images)
        _, predicted = outputs.max(1)
        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.numpy())

all_preds  = np.array(all_preds)
all_labels = np.array(all_labels)

cm     = confusion_matrix(all_labels, all_preds)
report = classification_report(all_labels, all_preds, output_dict=True)
final_acc = (all_preds == all_labels).mean()

print(f"Final test accuracy: {final_acc:.4f}")
print(classification_report(all_labels, all_preds))

# ── Save outputs ──────────────────────────────────────────────────────────────
os.makedirs("outputs", exist_ok=True)

torch.save(model.state_dict(), "outputs/mnist_cnn.pt")

with open("outputs/results.json", "w") as f:
    json.dump({
        "final_test_accuracy": float(final_acc),
        "epochs": EPOCHS,
        "history": history,
        "confusion_matrix": cm.tolist(),
        "classification_report": report,
        "model_params": total_params,
    }, f, indent=2)

print("Model saved to outputs/mnist_cnn.pt")
print("Results saved to outputs/results.json")
