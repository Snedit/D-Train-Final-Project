"""
House Price Predictor
=====================
Predicts California house prices using the California Housing dataset (~20k samples).
Trains Random Forest and Gradient Boosting regressors with 5-fold cross-validation.
Compares both models and saves feature importances and test metrics.
No grid search, no stacking — a solid mid-weight regression job.
"""

import json
import os
import numpy as np
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

print("Loading California Housing dataset...")
housing = fetch_california_housing()
X, y   = housing.data, housing.target
names  = list(housing.feature_names)
print(f"Samples: {X.shape[0]:,} | Features: {X.shape[1]}")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler    = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

cv = KFold(n_splits=5, shuffle=True, random_state=42)
results = {}

def evaluate(label, mdl):
    cv_scores = cross_val_score(mdl, X_train_s, y_train, cv=cv, scoring="r2", n_jobs=-1)
    mdl.fit(X_train_s, y_train)
    preds = mdl.predict(X_test_s)
    r2    = r2_score(y_test, preds)
    mae   = mean_absolute_error(y_test, preds)
    rmse  = np.sqrt(mean_squared_error(y_test, preds))
    print(f"  {label:<30} CV R²: {cv_scores.mean():.4f} ± {cv_scores.std():.4f} | Test R²: {r2:.4f} | MAE: {mae:.4f}")
    results[label] = {"cv_r2": float(cv_scores.mean()), "cv_std": float(cv_scores.std()),
                      "test_r2": float(r2), "mae": float(mae), "rmse": float(rmse)}
    return mdl

print("\nTraining models...")
rf  = evaluate("Random Forest (200 trees)",  RandomForestRegressor(n_estimators=200, max_depth=15, n_jobs=-1, random_state=42))
gbm = evaluate("Gradient Boosting (150 trees)", GradientBoostingRegressor(n_estimators=150, max_depth=5, learning_rate=0.1, random_state=42))

best_label = max(results, key=lambda k: results[k]["test_r2"])
print(f"\nBest model: {best_label} (R²={results[best_label]['test_r2']:.4f})")

importances = dict(sorted(zip(names, rf.feature_importances_.tolist()), key=lambda x: x[1], reverse=True))
print("\nFeature importances (Random Forest):")
for feat, imp in importances.items():
    print(f"  {feat:<20} {imp:.4f}")

os.makedirs("outputs", exist_ok=True)
with open("outputs/results.json", "w") as f:
    json.dump({"models": results, "best_model": best_label, "feature_importances": importances}, f, indent=2)

print("\nSaved to outputs/results.json")
