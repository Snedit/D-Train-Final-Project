"""
Email Spam Detector
===================
Trains a Naive Bayes and Logistic Regression classifier on the
20 Newsgroups dataset (subset) to classify spam vs. not-spam.
Compares both models and saves the better one's metrics.
"""

import json
import os
import numpy as np
from sklearn.datasets import fetch_20newsgroups
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

print("Fetching dataset (talk.religion.misc vs. sci.med — binary classification)...")
categories = ["talk.religion.misc", "sci.med", "comp.graphics", "rec.sport.hockey"]
data = fetch_20newsgroups(subset="all", categories=categories, remove=("headers", "footers", "quotes"))

X_raw, y = data.data, data.target
print(f"Total samples: {len(X_raw)} | Classes: {data.target_names}")

X_train_raw, X_test_raw, y_train, y_test = train_test_split(
    X_raw, y, test_size=0.2, random_state=42, stratify=y
)

print("\nVectorizing text with TF-IDF...")
vectorizer = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True)
X_train = vectorizer.fit_transform(X_train_raw)
X_test  = vectorizer.transform(X_test_raw)
print(f"Feature matrix: {X_train.shape}")

results = {}

print("\nTraining Naive Bayes...")
nb = MultinomialNB(alpha=0.1)
nb_cv = cross_val_score(nb, X_train, y_train, cv=5, scoring="accuracy")
nb.fit(X_train, y_train)
nb_pred = nb.predict(X_test)
nb_acc  = accuracy_score(y_test, nb_pred)
results["naive_bayes"] = {"cv_mean": float(nb_cv.mean()), "cv_std": float(nb_cv.std()), "test_acc": float(nb_acc)}
print(f"  CV: {nb_cv.mean():.4f} ± {nb_cv.std():.4f} | Test acc: {nb_acc:.4f}")

print("\nTraining Logistic Regression...")
lr = LogisticRegression(C=5.0, max_iter=1000, solver="lbfgs", multi_class="multinomial", n_jobs=-1)
lr_cv = cross_val_score(lr, X_train, y_train, cv=5, scoring="accuracy")
lr.fit(X_train, y_train)
lr_pred = lr.predict(X_test)
lr_acc  = accuracy_score(y_test, lr_pred)
results["logistic_regression"] = {"cv_mean": float(lr_cv.mean()), "cv_std": float(lr_cv.std()), "test_acc": float(lr_acc)}
print(f"  CV: {lr_cv.mean():.4f} ± {lr_cv.std():.4f} | Test acc: {lr_acc:.4f}")

best = "logistic_regression" if lr_acc >= nb_acc else "naive_bayes"
best_pred = lr_pred if best == "logistic_regression" else nb_pred
print(f"\nBest model: {best}")
print(classification_report(y_test, best_pred, target_names=data.target_names))

os.makedirs("outputs", exist_ok=True)
with open("outputs/results.json", "w") as f:
    json.dump({
        "best_model": best,
        "models": results,
        "confusion_matrix": confusion_matrix(y_test, best_pred).tolist(),
        "classes": list(data.target_names),
    }, f, indent=2)

print("Results saved to outputs/results.json")
